AgentGate — Devpost source upload

This compact archive contains the MIT-licensed app source, dependency locks, judge instructions, evaluation and security notes, submission copy, and thumbnail. It excludes credentials, local databases, downloaded dependencies, raw recordings, and the full video.

Judge quick start: see README.md. Run `python scripts/start_demo.py` for the isolated, simulated workspace. The hosted preview is https://agentgate-demo-console-2026.onrender.com; it uses simulated payments and rate-limited live AI planning.

Demo video: https://www.youtube.com/watch?v=1ey3pn47ujk
